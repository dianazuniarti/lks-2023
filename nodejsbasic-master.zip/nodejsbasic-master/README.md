# Apps Try Out LKSN Cloud Computing
## Install Dependency
* >npm install --prefix
## Running Program
* >npm run start-prod
## Test Program
* >Open Browser and access your ip + port, ex: localhost:8000
